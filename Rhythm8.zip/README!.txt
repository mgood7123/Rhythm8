How to install Rhythm 8.0

Windows Installation instructions:

Run Setup.exe
Choose your firmware.
Choose your PSP Drive.
Install and Enjoy!


Please visit our website for more samples, tips and tricks.
http://www.psprhythm.com

